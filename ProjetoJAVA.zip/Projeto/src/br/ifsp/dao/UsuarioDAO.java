package br.ifsp.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;


import br.ifsp.model.Usuario;


public class UsuarioDAO {
	private static UsuarioDAO instance;
	protected Session session;
	
	public static UsuarioDAO getInstance(Session session) {
		if (instance == null) {
			instance = new UsuarioDAO(session);
		}
		return instance;
	}

	private UsuarioDAO(Session session) {
		this.session = session;
	}

	//Retrieve (Recuperar) do cRud
	public Usuario getByLogin(final String l) {
		Query query = (Query) session.createQuery("from Usuario where login= :login");
		query.setParameter("login", l);
		List<Usuario> usuario = query.list();
		if(usuario.size() !=0)
			return usuario.get(0);
		
		return null;
	}

	//Retrieve (Recuperar) do cRud, mas retorna todas as linhas da tabela
	@SuppressWarnings("unchecked")
	public List<Usuario> findAll() {
		return session.createCriteria(Usuario.class).list();
	}

	//Create do Crud
	public void save(Usuario usuario) {
		try {
			session.getTransaction().begin();
			session.save(usuario);
			session.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			session.getTransaction().rollback();
		}
	}

	//Update do crUd
	public void merge(Usuario usuario) {
		try {
			session.getTransaction().begin();
			session.merge(usuario);
			session.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			session.getTransaction().rollback();
		}
	}

	//Delete do cruD
	public void remove(Usuario usuario) {
		try {
			session.getTransaction().begin();
			usuario = (Usuario) session.load(Usuario.class, usuario.getNome());
			session.delete(usuario);
			session.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			session.getTransaction().rollback();
		}
	}

	//Delete do cruD, passando o id ao inv�s do objeto
	public void removeByLogin(final String login) {
		try {
			Usuario usuario = getByLogin(login);
			System.out.println(usuario.getNome());
			remove(usuario);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
