package br.ifsp.dao;

import java.util.List;

import org.hibernate.Session;

import br.ifsp.model.Problema;



public class ProblemaDAO {
	private static ProblemaDAO instance;
	protected Session session;

	public static ProblemaDAO getInstance(Session session) {
		if (instance == null) {
			instance = new ProblemaDAO(session);
		}
		return instance;
	}

	private ProblemaDAO(Session session) {
		this.session = session;
	}

	//Retrieve (Recuperar) do cRud
	public Problema getById(final long l) {
		return (Problema) session.load(Problema.class, l);
	}

	//Retrieve (Recuperar) do cRud, mas retorna todas as linhas da tabela
	@SuppressWarnings("unchecked")
	public List<Problema> findAll() {
		return session.createCriteria(Problema.class).list();
	}

	//Create do Crud
	public void save(Problema problema) {
		try {
			session.getTransaction().begin();
			session.save(problema);
			session.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			session.getTransaction().rollback();
		}
	}

	//Update do crUd
	public void merge(Problema problema) {
		try {
			session.getTransaction().begin();
			session.merge(problema);
			session.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			session.getTransaction().rollback();
		}
	}

	//Delete do cruD
	public void remove(Problema problema) {
		try {
			session.getTransaction().begin();
			problema = (Problema) session.load(Problema.class, problema.getId());
			session.delete(problema);
			session.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			session.getTransaction().rollback();
		}
	}

	//Delete do cruD, passando o id ao inv�s do objeto
	public void removeById(final int id) {
		try {
			Problema problema = getById(id);
			remove(problema);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	

}
