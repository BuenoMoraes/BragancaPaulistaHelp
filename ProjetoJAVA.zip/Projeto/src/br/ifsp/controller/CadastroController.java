package br.ifsp.controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import org.hibernate.Session;

import br.ifsp.dao.UsuarioDAO;
import br.ifsp.hibernateAcesso.HibernateAcesso;
import br.ifsp.model.Problema;
import br.ifsp.model.Usuario;
import br.ifsp.view.TelaCadastro;
import br.ifsp.view.TelaLogin;

public class CadastroController {
	private TelaCadastro cadastro;
	
	public CadastroController(TelaCadastro cadastro) {
		this.cadastro = cadastro;
	}
	
	public void inicializaController() {
		this.cadastro.getButton().addActionListener (new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(confirmaCadastro() == true) {
				//cria��o de usuario
				cadastro.getFrmCadastro().dispose();
				Problema problema = new Problema(1,"c�digo","nao funfa","hoje porra","l");
				ArrayList<Problema> problemas = new ArrayList();
				problemas.add(problema);
				Usuario usuario = new Usuario(cadastro.getFrmtdtxtfldNome().getText(),cadastro.getFrmtdtxtfldEmail().getText(),Integer.parseInt(cadastro.getPasswordField().getText()));
				Session session = HibernateAcesso.getSessionFactory().openSession();
				UsuarioDAO dao = UsuarioDAO.getInstance(session);
				dao.save(usuario);	
				TelaLogin telaLogin = new TelaLogin();
				LoginController l = new LoginController(telaLogin,usuario);
				l.inicializaController();
				}
			}
		});
	}
	
	private boolean confirmaCadastro() {
		String nomeInserido = this.cadastro.getFrmtdtxtfldNome().getText();
		String usuarioInserido = this.cadastro.getFrmtdtxtfldNome().getText();
		String senhaInserida = this.cadastro.getFrmtdtxtfldNome().getText();
		if((nomeInserido != "") && (usuarioInserido != "")  && (senhaInserida != "") ){
			return true;
		}else {
			return false;
		}
	}
}
