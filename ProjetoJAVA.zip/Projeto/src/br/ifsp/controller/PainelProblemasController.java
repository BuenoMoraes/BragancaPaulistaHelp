package br.ifsp.controller;

import br.ifsp.model.Problema;
import br.ifsp.view.PainelProblemas;

public class PainelProblemasController {
	private Problema problemas;
	private PainelProblemas panel;
	
	public PainelProblemasController(PainelProblemas panelP, Problema p) {
		panel = panelP;
		problemas = p;
	}
	
	public void inicializaController() {
		System.out.println(problemas);
		System.out.println(problemas.getId());
		System.out.println(problemas.getTipo());
		panel.getLabelID().setText(Integer.toString(problemas.getId()));
		panel.getLabelTipo().setText(problemas.getTipo());
		panel.getDescricao().setText(problemas.getDescricao());
		panel.getLabelData().setText(problemas.getData());
	}
}
