package br.ifsp.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import br.ifsp.model.Problema;
import br.ifsp.model.Usuario;
import br.ifsp.view.TelaAddProblemas;

public class AddProblemasController {
	private TelaAddProblemas telaAddProblemas;
	
	public AddProblemasController(TelaAddProblemas telaAddProblemas) {
		this.telaAddProblemas = telaAddProblemas;
	}
	
	public void inicializaController() {
		this.telaAddProblemas.getButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("BOAAAAAAAAAAAAAAAAA");
				Problema prob = new Problema();
			}
			
		});
		
	}

}
