package br.ifsp.controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.hibernate.Session;

import br.ifsp.dao.ProblemaDAO;
import br.ifsp.dao.UsuarioDAO;
import br.ifsp.hibernateAcesso.HibernateAcesso;
import br.ifsp.model.Usuario;
import br.ifsp.view.TelaDeletarProblemas;
import br.ifsp.view.TelaMenu;

public class DeletarProblemasController {
	private TelaDeletarProblemas telaDelProblemas;
	
	public DeletarProblemasController(TelaDeletarProblemas telaDelProblemas){
		this.telaDelProblemas = telaDelProblemas;
	}
	
	public void inicializaController() {
		this.telaDelProblemas.getButton().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaMenu tela = new TelaMenu(null);
				Session session = HibernateAcesso.getSessionFactory().openSession();
				ProblemaDAO dao = ProblemaDAO.getInstance(session);
				
			}
		});	
	}
		

}
