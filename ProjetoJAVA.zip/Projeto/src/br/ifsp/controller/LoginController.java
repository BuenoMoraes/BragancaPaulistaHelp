package br.ifsp.controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.hibernate.Session;

import br.ifsp.dao.UsuarioDAO;
import br.ifsp.hibernateAcesso.HibernateAcesso;
import br.ifsp.model.Usuario;
import br.ifsp.view.TelaCadastro;
import br.ifsp.view.TelaLogin;
import br.ifsp.view.TelaMenu;
import br.ifsp.view.TelaProblemas;

public class LoginController {
	private TelaLogin login;
	private Usuario usuario;
	private String logado;
	
	public LoginController(TelaLogin login, Usuario usuario){
		this.login = login;
		this.usuario = usuario;
	}
	
	public void inicializaController() {
		this.login.getButton().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean resultado = validaLogin();
				if(resultado) {
					login.getFrame().dispose();
					logado = login.getTextField().getText();
					TelaMenu menu = new TelaMenu(logado);
					MenuController contMenu = new MenuController(menu);
					contMenu.inicializaController();
				}else {
					System.out.println("Login n�o encontrado!");
				}				
			}
		});		
		
		this.login.getCadastrar().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {		
					TelaCadastro telaCadastro = new TelaCadastro();
					CadastroController controller = new CadastroController(telaCadastro);
					controller.inicializaController();
			}
		});
	}
	
	private boolean validaLogin() {
		//usar hibernate com dao para pegar infos do usuario
		String usuarioInserido = this.login.getTextField().getText();
		String senhaInserida = new String(this.login.getPasswordField().getPassword());
		Session session = HibernateAcesso.getSessionFactory().openSession();
		UsuarioDAO dao = UsuarioDAO.getInstance(session);
		Usuario usuarioBanco = dao.getByLogin(usuarioInserido);

		boolean resultado = usuarioInserido.equals(usuarioBanco.getLogin()) &&
				(senhaInserida.equals(Integer.toString(usuarioBanco.getSenha())));
		
		return resultado;
	}
}
