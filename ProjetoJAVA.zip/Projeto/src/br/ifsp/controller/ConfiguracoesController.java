package br.ifsp.controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.hibernate.Session;

import br.ifsp.dao.UsuarioDAO;
import br.ifsp.hibernateAcesso.HibernateAcesso;
import br.ifsp.model.Usuario;
import br.ifsp.principal.Main;
import br.ifsp.view.TelaCadastro;
import br.ifsp.view.TelaConfiguracoes;
import br.ifsp.view.TelaLogin;
import br.ifsp.view.TelaMenu;

public class ConfiguracoesController {
	private TelaConfiguracoes configuracoes;
	private String logado;
	
	public ConfiguracoesController(TelaConfiguracoes configuracoes, String logado) {
		this.configuracoes = configuracoes;
		this.logado=logado;
	}
	
	public void inicializaController() {
		this.configuracoes.getBtnAtualizar().addActionListener (new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaMenu telamenu = new TelaMenu(logado);
				//Fun��o de atualizar usuario
				Session session = HibernateAcesso.getSessionFactory().openSession();
				UsuarioDAO dao = UsuarioDAO.getInstance(session);
				
				
				
				
			}
		});
		
		this.configuracoes.getBtnExcluir().addActionListener (new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					TelaLogin telalogin = new TelaLogin();
					LoginController contLogin = new LoginController(telalogin, null);
					//Fun��o de apagar usuario
					Session session = HibernateAcesso.getSessionFactory().openSession();
					UsuarioDAO dao = UsuarioDAO.getInstance(session);
					dao.removeByLogin(configuracoes.getFrmtdtxtfldEmail().getText());
					contLogin.inicializaController();
					
				
			}
		
		});
	}
	
}
