package br.ifsp.controller;
import java.util.ArrayList;

import br.ifsp.model.Problema;
import br.ifsp.model.Usuario;
import br.ifsp.view.PainelProblemas;
import br.ifsp.view.TelaProblemas;

public class TelaProblemasController {
	private TelaProblemas telaProblemas;
	private Usuario usuario;

	public TelaProblemasController(TelaProblemas telaProblemas, Usuario usuario) {
		this.telaProblemas = telaProblemas;
		this.usuario = usuario;
	}
	
	public void inicializaProblemasController() {
		ArrayList<Problema> problemas = (ArrayList<Problema>)usuario.getProblemas();
		for(Problema p : problemas) {
			PainelProblemas panelP = new PainelProblemas();
			PainelProblemasController panelPController = new PainelProblemasController(panelP, p);
			panelPController.inicializaController();
			telaProblemas.addPainelProblemas(panelP);
		}
		
		
		telaProblemas.getUsuarioLabel().setText(usuario.getNome());
	}
}
