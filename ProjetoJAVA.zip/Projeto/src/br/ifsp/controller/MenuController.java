package br.ifsp.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import br.ifsp.model.Usuario;
import br.ifsp.view.TelaAddProblemas;
import br.ifsp.view.TelaConfiguracoes;
import br.ifsp.view.TelaContatos;
import br.ifsp.view.TelaDeletarProblemas;
import br.ifsp.view.TelaFAQ;
import br.ifsp.view.TelaHome;
import br.ifsp.view.TelaLogin;
import br.ifsp.view.TelaMenu;
import br.ifsp.view.TelaProblemas;

public class MenuController {
	private TelaMenu telaMenu;
	private String logado;
	
	public MenuController(TelaMenu telaMenu){
		this.telaMenu = telaMenu;
	}
	
	public void inicializaController() {
		this.telaMenu.getButton1().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaHome c = new TelaHome();
			}
			
		});
		
		this.telaMenu.getButton2().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaAddProblemas m = new TelaAddProblemas();
				AddProblemasController add = new AddProblemasController(m);
				add.inicializaController();
			}
			
		});
		this.telaMenu.getButton3().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaProblemas l = new TelaProblemas();
			}
			
		});
		this.telaMenu.getButton4().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			TelaConfiguracoes c = new TelaConfiguracoes();
			ConfiguracoesController confController = new ConfiguracoesController(c,logado);
			confController.inicializaController();
			}
			
		});
		this.telaMenu.getButton5().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaFAQ f = new TelaFAQ();
			}
			
		});
		this.telaMenu.getButton6().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaContatos cont = new TelaContatos();
			}
			
		});
		this.telaMenu.getButton7().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TelaDeletarProblemas t = new TelaDeletarProblemas();
				DeletarProblemasController del = new DeletarProblemasController(t);
				del.inicializaController();		
			}
			
		});
	}
}
