package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPasswordField;
import javax.swing.JEditorPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;

public class TelaHome {
	
	 JFrame Login;
	 
		public TelaHome() {
		
			Login = new JFrame();
			Login.setTitle("Home");
			Login.setBounds(100, 100, 701, 503);
			Login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			panel.setBackground(Color.BLACK);
			panel.setLayout(null);
			Login.getContentPane().add(panel, BorderLayout.CENTER);
			
			JLabel label = new JLabel("Bragan\u00E7a Paulista Help");
			label.setForeground(Color.WHITE);
			label.setFont(new Font("Times New Roman", Font.BOLD, 51));
			label.setBackground(Color.WHITE);
			label.setBounds(80, 36, 523, 84);
			panel.add(label);
			
			JLabel label_1 = new JLabel("Introdu\u00E7\u00E3o");
			label_1.setForeground(Color.WHITE);
			label_1.setFont(new Font("Times New Roman", Font.BOLD, 17));
			label_1.setBackground(Color.WHITE);
			label_1.setBounds(116, 258, 81, 20);
			panel.add(label_1);
			
			JLabel label_2 = new JLabel("Objetivo");
			label_2.setForeground(Color.WHITE);
			label_2.setFont(new Font("Times New Roman", Font.BOLD, 17));
			label_2.setBackground(Color.WHITE);
			label_2.setBounds(445, 258, 81, 20);
			panel.add(label_2);
			
			JTextPane txtpnUmProjetoQue = new JTextPane();
			txtpnUmProjetoQue.setText("Um projeto que ajuda os cidad\u00E3os de Bragan\u00E7a Paulista\r\na denunciar irregularidades na cidade");
			txtpnUmProjetoQue.setForeground(Color.WHITE);
			txtpnUmProjetoQue.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			txtpnUmProjetoQue.setBackground(Color.BLACK);
			txtpnUmProjetoQue.setBounds(57, 289, 201, 84);
			panel.add(txtpnUmProjetoQue);
			
			JTextPane txtpnEsseProjetoBusca = new JTextPane();
			txtpnEsseProjetoBusca.setText("Esse Projeto busca aumentar a qualidade de vida dos cidad\u00E3os de Bragan\u00E7a Paulista");
			txtpnEsseProjetoBusca.setForeground(Color.WHITE);
			txtpnEsseProjetoBusca.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			txtpnEsseProjetoBusca.setBackground(Color.BLACK);
			txtpnEsseProjetoBusca.setBounds(402, 289, 201, 84);
			panel.add(txtpnEsseProjetoBusca);
			
			JButton btnVoltar = new JButton("Voltar");
			btnVoltar.setBounds(586, 430, 89, 23);
			btnVoltar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					TelaMenu m = new TelaMenu(null);
				}
			});
			panel.add(btnVoltar);
			
			Login.setVisible(true);

		}
}
