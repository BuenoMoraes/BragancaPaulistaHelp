package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Button;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.List;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JFormattedTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;

public class TelaDeletarProblemas {
	
	private JFrame frmDelProblemas;
	private JButton btnEnviarProblema;
	private JFormattedTextField	id;
;
	

	public JButton getButton() {
		return btnEnviarProblema;
	}
	
	public  JFormattedTextField getId() {
		return id;
	}
	


	/**
	 * Create the application.
	 */
	public TelaDeletarProblemas() {
		initialize();
		frmDelProblemas.setVisible(true);
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frmDelProblemas = new JFrame();
		frmDelProblemas.setTitle("Add Problemas");
		frmDelProblemas.setVisible(true);
		frmDelProblemas.setBounds(100, 100, 701, 501);
		frmDelProblemas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setLayout(null);
		frmDelProblemas.getContentPane().add(panel, BorderLayout.CENTER);
		
		JLabel lblCadastrarse = new JLabel("Deletar Problemas");
		lblCadastrarse.setFont(new Font("Times New Roman", Font.BOLD, 55));
		lblCadastrarse.setBackground(Color.WHITE);
		lblCadastrarse.setForeground(Color.WHITE);
		lblCadastrarse.setBounds(114, 33, 455, 62);
		panel.add(lblCadastrarse);
		
		btnEnviarProblema = new JButton("Deletar Problema");
		btnEnviarProblema.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnEnviarProblema.setBounds(266, 295, 148, 30);
		panel.add(btnEnviarProblema);
		
		id = new JFormattedTextField();
		id.setBounds(53, 235, 573, 30);
		panel.add(id);
		
		JLabel Textoid = new JLabel("ID:");
		Textoid.setForeground(Color.WHITE);
		Textoid.setFont(new Font("Times New Roman", Font.BOLD, 19));
		Textoid.setBackground(Color.WHITE);
		Textoid.setBounds(53, 215, 286, 25);
		panel.add(Textoid);
		
		JLabel lblEssaATela = new JLabel("Essa a tela tem como funcionalidade deletar um problema j\u00E1 cadastrado a partir de seu ID");
		lblEssaATela.setForeground(Color.WHITE);
		lblEssaATela.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblEssaATela.setBackground(Color.WHITE);
		lblEssaATela.setBounds(53, 91, 594, 133);
		panel.add(lblEssaATela);
		
		

	}
}
