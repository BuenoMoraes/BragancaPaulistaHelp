package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Button;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.List;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JFormattedTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;

public class TelaCadastro {
	
	private JFrame frmCadastro;
	private JButton button;
	private JFormattedTextField frmtdtxtfldNome;
	private JFormattedTextField frmtdtxtfldEmail;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	

	public JFormattedTextField getFrmtdtxtfldNome() {
		return frmtdtxtfldNome;
	}

	public JFormattedTextField getFrmtdtxtfldEmail() {
		return frmtdtxtfldEmail;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public JPasswordField getPasswordField_1() {
		return passwordField_1;
	}

	public JFrame getFrmCadastro() {
		return frmCadastro;
	}

	public JButton getButton() {
		return button;
	}


	/**
	 * Create the application.
	 */
	public TelaCadastro() {
		initialize();
		frmCadastro.setVisible(true);
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frmCadastro = new JFrame();
		frmCadastro.setTitle("Cadastro");
		frmCadastro.setVisible(true);
		frmCadastro.setBounds(100, 100, 701, 501);
		frmCadastro.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setLayout(null);
		frmCadastro.getContentPane().add(panel, BorderLayout.CENTER);
		
		button = new JButton("Cadastrar-se");
		
		
		button.setBounds(274, 336, 142, 37);
		panel.add(button);
		
		frmtdtxtfldNome = new JFormattedTextField();
		frmtdtxtfldNome.setBounds(55, 125, 573, 30);
		panel.add(frmtdtxtfldNome);
		
		frmtdtxtfldEmail = new JFormattedTextField();
		frmtdtxtfldEmail.setBounds(55, 197, 573, 30);
		panel.add(frmtdtxtfldEmail);
		
		JLabel lblCadastrarse = new JLabel("Cadastrar-se");
		lblCadastrarse.setFont(new Font("Times New Roman", Font.BOLD, 55));
		lblCadastrarse.setBackground(Color.WHITE);
		lblCadastrarse.setForeground(Color.WHITE);
		lblCadastrarse.setBounds(196, 34, 305, 62);
		panel.add(lblCadastrarse);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(55, 275, 286, 30);
		panel.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(362, 275, 266, 30);
		panel.add(passwordField_1);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNome.setBackground(Color.WHITE);
		lblNome.setBounds(55, 99, 105, 25);
		panel.add(lblNome);
		
		JLabel lblNomeDeUsuario = new JLabel("Nome de usuario:");
		lblNomeDeUsuario.setForeground(Color.WHITE);
		lblNomeDeUsuario.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNomeDeUsuario.setBackground(Color.WHITE);
		lblNomeDeUsuario.setBounds(55, 173, 171, 25);
		panel.add(lblNomeDeUsuario);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setForeground(Color.WHITE);
		lblSenha.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblSenha.setBackground(Color.WHITE);
		lblSenha.setBounds(55, 249, 105, 25);
		panel.add(lblSenha);
		
		JLabel lblConfirmarSenha = new JLabel("Confirmar senha:");
		lblConfirmarSenha.setForeground(Color.WHITE);
		lblConfirmarSenha.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblConfirmarSenha.setBackground(Color.WHITE);
		lblConfirmarSenha.setBounds(361, 249, 151, 25);
		panel.add(lblConfirmarSenha);
		
		

	}
}
