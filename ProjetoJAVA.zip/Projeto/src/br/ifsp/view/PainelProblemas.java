package br.ifsp.view;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;

public class PainelProblemas {

	private JPanel panel;
	private JTextField descricao;
	private JLabel labelID;
	private JLabel labelTipo;
	private JLabel labelData;
	
	public JPanel getPanel() {
		return panel;
	}

	public JTextField getDescricao() {
		return descricao;
	}

	public JLabel getLabelID() {
		return labelID;
	}

	public JLabel getLabelTipo() {
		return labelTipo;
	}

	public JLabel getLabelData() {
		return labelData;
	}

	public PainelProblemas() {
		initialize();
	}

	/**
	 * @wbp.parser.entryPoint
	 */
	
	private void initialize() {
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setPreferredSize(new Dimension(500, 186));
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setLayout(null);
		
		JLabel lblId = new JLabel("ID");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblId.setBounds(10, 11, 23, 14);
		panel.add(lblId);
		
		labelID = new JLabel("<< num>>");
		labelID.setFont(new Font("Tahoma", Font.PLAIN, 14));
		labelID.setBounds(55, 8, 72, 20);
		panel.add(labelID);
		
		
		JLabel label_1 = new JLabel("-");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_1.setBounds(149, 11, 23, 14);
		panel.add(label_1);
		
		labelTipo = new JLabel("<< Tipo Problema >>");
		labelTipo.setFont(new Font("Tahoma", Font.BOLD, 19));
		labelTipo.setBounds(182, 4, 218, 27);
		panel.add(labelTipo);
		
		JLabel lblDescrio = new JLabel("DESCRI\u00C7\u00C3O:");
		lblDescrio.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDescrio.setBounds(10, 75, 83, 14);
		panel.add(lblDescrio);
		
		descricao = new JTextField();
		descricao.setBounds(10, 100, 480, 75);
		panel.add(descricao);
		descricao.setColumns(10);
		
		JLabel lblPreo = new JLabel("DATA:");
		lblPreo.setForeground(Color.BLACK);
		lblPreo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPreo.setBounds(10, 36, 58, 28);
		panel.add(lblPreo);
		
		labelData = new JLabel("<<Data>>");
		labelData.setFont(new Font("Tahoma", Font.PLAIN, 14));
		labelData.setBounds(65, 43, 91, 14);
		panel.add(labelData);
		
	}
	
	

}
