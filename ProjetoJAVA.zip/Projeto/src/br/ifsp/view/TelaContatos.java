package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;

public class TelaContatos {
	
	 JFrame Login;
	 
		public TelaContatos() {
		
			Login = new JFrame();
			Login.setTitle("Contatos");
			Login.setBounds(100, 100, 701, 503);
			Login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			panel.setBackground(Color.BLACK);
			panel.setLayout(null);
			Login.getContentPane().add(panel, BorderLayout.CENTER);
			
			JButton btnVoltar = new JButton("Voltar");
			btnVoltar.setBounds(586, 430, 89, 23);
			btnVoltar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					TelaMenu m = new TelaMenu(null);
				}
			});
			panel.add(btnVoltar);
			
			JLabel label = new JLabel("Contatos");
			label.setForeground(Color.WHITE);
			label.setFont(new Font("Times New Roman", Font.BOLD, 51));
			label.setBackground(Color.WHITE);
			label.setBounds(234, 26, 197, 60);
			panel.add(label);
			
			JLabel label_1 = new JLabel("Encontre aqui informa\u00E7\u00F5es uteis para melhor atendimento");
			label_1.setForeground(Color.WHITE);
			label_1.setFont(new Font("Times New Roman", Font.BOLD, 22));
			label_1.setBackground(Color.WHITE);
			label_1.setBounds(56, 101, 574, 84);
			panel.add(label_1);
			
			JTextPane textPane = new JTextPane();
			textPane.setText("Prefeitura\r\nEndere\u00E7o:Av Antonio Pires Pimentel,2015\r\nTelefone:+55 11 4030-7100\r\n\r\nSecret\u00E1ria de obras e servi\u00E7os\r\nEndere\u00E7o:Avenida Francisco Samuel Luchesi Filho, 85 - Jd. Julio de Mesquita Filho\r\nTelefone:(11) 4035-8540");
			textPane.setForeground(Color.WHITE);
			textPane.setFont(new Font("Times New Roman", Font.BOLD, 20));
			textPane.setBackground(Color.BLACK);
			textPane.setBounds(184, 179, 362, 242);
			panel.add(textPane);
			
			Login.setVisible(true);

		}
}
