package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Button;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.List;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JFormattedTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;

import br.ifsp.controller.AddProblemasController;

import javax.swing.JPasswordField;

public class TelaAddProblemas {
	
	private JFrame frmAddProblemas;
	private JButton btnEnviarProblema;
	private JFormattedTextField tipo;
	private JFormattedTextField descricao;
	private JFormattedTextField data;
	private JFormattedTextField	id;
	

	public JFormattedTextField getTipo() {
		return tipo;
	}

	public JFormattedTextField getDescricao() {
		return descricao;
	}

	public  JFormattedTextField getData() {
		return data;
	}


	public JFrame getAddProblemas() {
		return frmAddProblemas;
	}

	public JButton getButton() {
		return btnEnviarProblema;
	}
	
	public  JFormattedTextField getId() {
		return id;
	}



	/**
	 * Create the application.
	 */
	public TelaAddProblemas() {
		initialize();
		frmAddProblemas.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frmAddProblemas = new JFrame();
		frmAddProblemas.setTitle("Add Problemas");
		frmAddProblemas.setVisible(true);
		frmAddProblemas.setBounds(100, 100, 701, 501);
		frmAddProblemas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setLayout(null);
		frmAddProblemas.getContentPane().add(panel, BorderLayout.CENTER);
		
		tipo = new JFormattedTextField();
		tipo.setBounds(55, 204, 573, 30);
		panel.add(tipo);
		
		descricao = new JFormattedTextField();
		descricao.setBounds(55, 281, 573, 30);
		panel.add(descricao);
		
		JLabel lblCadastrarse = new JLabel("Adicionar Problemas");
		lblCadastrarse.setFont(new Font("Times New Roman", Font.BOLD, 55));
		lblCadastrarse.setBackground(Color.WHITE);
		lblCadastrarse.setForeground(Color.WHITE);
		lblCadastrarse.setBounds(92, 34, 508, 62);
		panel.add(lblCadastrarse);
		
		JLabel lblNome = new JLabel("Tipo(buraco, poste sem luz...):");
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNome.setBackground(Color.WHITE);
		lblNome.setBounds(55, 179, 286, 25);
		panel.add(lblNome);
		
		JLabel lblNomeDeUsuario = new JLabel("Descri\u00E7\u00E3o:");
		lblNomeDeUsuario.setForeground(Color.WHITE);
		lblNomeDeUsuario.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNomeDeUsuario.setBackground(Color.WHITE);
		lblNomeDeUsuario.setBounds(55, 257, 171, 25);
		panel.add(lblNomeDeUsuario);
		
		JLabel lblSenha = new JLabel("Data:");
		lblSenha.setForeground(Color.WHITE);
		lblSenha.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblSenha.setBackground(Color.WHITE);
		lblSenha.setBounds(55, 325, 105, 25);
		panel.add(lblSenha);
		
		data = new JFormattedTextField();
		data.setBounds(55, 349, 573, 30);
		panel.add(data);
		
		btnEnviarProblema = new JButton("Enviar Problema");
		btnEnviarProblema.setBounds(285, 408, 148, 30);
		panel.add(btnEnviarProblema);
		
		id = new JFormattedTextField();
		id.setBounds(55, 138, 573, 30);
		panel.add(id);
		
		JLabel Textoid = new JLabel("ID:");
		Textoid.setForeground(Color.WHITE);
		Textoid.setFont(new Font("Times New Roman", Font.BOLD, 19));
		Textoid.setBackground(Color.WHITE);
		Textoid.setBounds(55, 118, 286, 25);
		panel.add(Textoid);
		

	}
}
