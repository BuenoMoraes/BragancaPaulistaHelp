package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JEditorPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class TelaFAQ {

	JFrame frame1;
	private JTextField txtOndeAtuamos;
	private JTextField txtTemOutraPergunta;
	private JTextField txtComoEncontroLatitude;

	public TelaFAQ() {
		frame1 = new JFrame();
		frame1.setTitle("FAQ");
		frame1.setBounds(100, 100, 701, 501);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setLayout(null);
		frame1.getContentPane().add(panel, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("FAQ-Perguntas Frequentes");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 51));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(10, 0, 675, 84);
		panel.add(lblNewLabel);
		
		txtOndeAtuamos = new JTextField();
		txtOndeAtuamos.setEditable(false);
		txtOndeAtuamos.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtOndeAtuamos.setText("Onde Atuamos?");
		txtOndeAtuamos.setBounds(41, 95, 293, 27);
		panel.add(txtOndeAtuamos);
		txtOndeAtuamos.setColumns(10);
		
		JTextPane txtpnAtuamosNaCidade = new JTextPane();
		txtpnAtuamosNaCidade.setEditable(false);
		txtpnAtuamosNaCidade.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtpnAtuamosNaCidade.setText("Atuamos na cidade e Bragan\u00E7a Paulista, buscando melhorar a vida da popula\u00E7\u00E3o");
		txtpnAtuamosNaCidade.setBounds(41, 133, 293, 84);
		panel.add(txtpnAtuamosNaCidade);
		
		txtTemOutraPergunta = new JTextField();
		txtTemOutraPergunta.setEditable(false);
		txtTemOutraPergunta.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtTemOutraPergunta.setText("Tem outra pergunta?");
		txtTemOutraPergunta.setColumns(10);
		txtTemOutraPergunta.setBounds(363, 95, 293, 27);
		panel.add(txtTemOutraPergunta);
		
		JTextPane txtpnDigiteSuaDvida = new JTextPane();
		txtpnDigiteSuaDvida.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtpnDigiteSuaDvida.setText("Digite sua d\u00FAvida aqui");
		txtpnDigiteSuaDvida.setBounds(363, 133, 293, 245);
		panel.add(txtpnDigiteSuaDvida);
		
		txtComoEncontroLatitude = new JTextField();
		txtComoEncontroLatitude.setEditable(false);
		txtComoEncontroLatitude.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtComoEncontroLatitude.setText("Como encontro latitude e longitude de um ponto?");
		txtComoEncontroLatitude.setColumns(10);
		txtComoEncontroLatitude.setBounds(41, 228, 293, 27);
		panel.add(txtComoEncontroLatitude);
		
		JTextPane txtpnParaEncontrarEsses = new JTextPane();
		txtpnParaEncontrarEsses.setEditable(false);
		txtpnParaEncontrarEsses.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtpnParaEncontrarEsses.setText("Para encontrar esses dados, busque no google maps o endere\u00E7o que deseja e copie a latitude e longitude que o google indicar.");
		txtpnParaEncontrarEsses.setBounds(41, 266, 293, 112);
		panel.add(txtpnParaEncontrarEsses);
		
		JButton btnNewButton = new JButton("Voltar ao menu");
		btnNewButton.setBounds(10, 424, 153, 27);
		btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
				TelaMenu m = new TelaMenu(null);
			}
		});
		panel.add(btnNewButton);
		
		JButton button2 = new JButton("Enviar Pergunta");
		button2.setBounds(522, 424, 153, 27);
		panel.add(button2);
		
		frame1.setVisible(true);
	}
}
