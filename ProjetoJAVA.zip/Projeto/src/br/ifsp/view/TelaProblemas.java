package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import java.awt.Color;

public class TelaProblemas {
	private JFrame frame;
	private String userName;
	private JPanel panel_1;
	JLabel label;
	/**
	 * Create the application.
	 * @param object 
	 * @param string 
	 */
	public TelaProblemas() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 563, 384);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(700, 500);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JLabel lblUsurio = new JLabel("Usu\u00E1rio:");
		lblUsurio.setBackground(Color.WHITE);
		lblUsurio.setForeground(Color.BLACK);
		lblUsurio.setFont(new Font("Tahoma", Font.PLAIN, 29));
		panel.add(lblUsurio);
		
		label = new JLabel("<<Usu\u00E1rio>>");
		label.setText(userName);
		label.setFont(new Font("Tahoma", Font.PLAIN, 18));
		panel.add(label);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.BLACK);
		panel_1.setLayout(new GridLayout(0, 1, 0, 0));

		JScrollPane scrollPane = new JScrollPane(panel_1);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);		
		//panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("Menu");
		frame.getContentPane().add(btnNewButton, BorderLayout.SOUTH);
		btnNewButton.setBounds(541, 343, 100, 59);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TelaMenu menu = new TelaMenu(null);
			}
		});
	}

	public void addPainelProblemas(PainelProblemas panelP) {
		panel_1.add(panelP.getPanel());		
	}

	public JLabel getUsuarioLabel() {
		return label;
	}
}
