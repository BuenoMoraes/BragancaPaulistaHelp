package br.ifsp.view;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Button;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.List;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JFormattedTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;

public class TelaConfiguracoes {
	
	private JFrame frmConfiguracoes;
	private JButton btnAtualizar, btnExcluir;
	private JFormattedTextField frmtdtxtfldNome;
	private JFormattedTextField frmtdtxtfldEmail;
	private JPasswordField senha;
	

	public JFormattedTextField getFrmtdtxtfldNome() {
		return frmtdtxtfldNome;
	}

	public JFormattedTextField getFrmtdtxtfldEmail() {
		return frmtdtxtfldEmail;
	}

	public JPasswordField getSenha() {
		return senha;
	}

	public JFrame getFrmConfiguracoes() {
		return frmConfiguracoes;
	}

	public JButton getBtnAtualizar() {
		return btnAtualizar;
	}
	
	public JButton getBtnExcluir() {
		return btnExcluir;
	}


	/**
	 * Create the application.
	 */
	public TelaConfiguracoes() {
		initialize();
		frmConfiguracoes.setVisible(true);
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frmConfiguracoes = new JFrame();
		frmConfiguracoes.setTitle("Configura��es");
		frmConfiguracoes.setVisible(true);
		frmConfiguracoes.setBounds(100, 100, 701, 501);
		frmConfiguracoes.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setLayout(null);
		frmConfiguracoes.getContentPane().add(panel, BorderLayout.CENTER);
		
		btnAtualizar = new JButton("Atualizar");	
		btnAtualizar.setBounds(486, 403, 142, 37);
		panel.add(btnAtualizar);
		
		frmtdtxtfldNome = new JFormattedTextField();
		frmtdtxtfldNome.setBounds(55, 217, 573, 30);
		panel.add(frmtdtxtfldNome);
		
		frmtdtxtfldEmail = new JFormattedTextField();
		frmtdtxtfldEmail.setBounds(55, 272, 573, 30);
		panel.add(frmtdtxtfldEmail);
		
		JLabel lblConfiguracoes = new JLabel("Configura\u00E7\u00F5es");
		lblConfiguracoes.setFont(new Font("Times New Roman", Font.BOLD, 55));
		lblConfiguracoes.setBackground(Color.WHITE);
		lblConfiguracoes.setForeground(Color.WHITE);
		lblConfiguracoes.setBounds(170, 34, 366, 62);
		panel.add(lblConfiguracoes);
		
		JLabel lblNomeDeUsuario = new JLabel("Nome de usuario:");
		lblNomeDeUsuario.setForeground(Color.WHITE);
		lblNomeDeUsuario.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNomeDeUsuario.setBackground(Color.WHITE);
		lblNomeDeUsuario.setBounds(55, 246, 171, 25);
		panel.add(lblNomeDeUsuario);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setForeground(Color.WHITE);
		lblSenha.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblSenha.setBackground(Color.WHITE);
		lblSenha.setBounds(55, 303, 105, 25);
		panel.add(lblSenha);
		
		JLabel lblNestaTelaDe = new JLabel("Nesta tela de configura\u00E7\u00F5es, voc\u00EA pode atualizar ou excluir seus dados");
		lblNestaTelaDe.setForeground(Color.WHITE);
		lblNestaTelaDe.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNestaTelaDe.setBackground(Color.WHITE);
		lblNestaTelaDe.setBounds(42, 107, 599, 62);
		panel.add(lblNestaTelaDe);
		
		btnExcluir = new JButton("Excluir ");
		btnExcluir.setBounds(334, 403, 142, 37);
		panel.add(btnExcluir);
		
		senha = new JPasswordField();
		senha.setBounds(55, 334, 573, 30);
		panel.add(senha);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNome.setBackground(Color.WHITE);
		lblNome.setBounds(55, 191, 171, 25);
		panel.add(lblNome);
		
		

	}
}
