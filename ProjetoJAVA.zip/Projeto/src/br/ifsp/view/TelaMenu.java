package br.ifsp.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.Container;

import javax.swing.SwingConstants;

import br.ifsp.controller.AddProblemasController;
import br.ifsp.controller.ConfiguracoesController;
import br.ifsp.controller.DeletarProblemasController;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPasswordField;
import javax.swing.JEditorPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaMenu {
	 private JPanel panel;
	 private JFrame menu;
	 private JButton button1, button2, button3, button4, button5, button6, button7;
	 private String logado;
		
		public JPanel getPanel() {
			return panel;
		}

		public JFrame getMenu() {
			return menu;
		}
		
		
	 	public JButton getButton1() {
			return button1;
		}

		public JButton getButton2() {
			return button2;
		}

		public JButton getButton3() {
			return button3;
		}

		public JButton getButton4() {
			return button4;
		}

		public JButton getButton5() {
			return button5;
		}

		public JButton getButton6() {
			return button6;
		}
		
		public JButton getButton7() {
			return button7;
		}
		

		/**
		 * Create the application.
		 */
	 
		public TelaMenu(String logado) {
			initialize();
			menu.setVisible(true);
			this.logado=logado;
		}
	

		/**
		 * Initialize the contents of the frame.
		 */
		public void initialize() {
		
			menu = new JFrame();
			menu.setBounds(100, 100, 701, 503);
			menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			panel.setBackground(Color.BLACK);
			panel.setLayout(null);
			menu.getContentPane().add(panel, BorderLayout.CENTER);
			
			JLabel lblLogin = new JLabel("Menu");
			lblLogin.setForeground(Color.WHITE);
			lblLogin.setBackground(Color.WHITE);
			lblLogin.setFont(new Font("Times New Roman", Font.BOLD, 51));
			lblLogin.setBounds(261, 0, 145, 126);
			panel.add(lblLogin);
			
			button1 = new JButton("Home");
			button1.setBounds(126, 123, 154, 41);
			panel.add(button1);
			
			button2 = new JButton("Adicionar Problemas");
			button2.setBounds(402, 196, 154, 41);
			panel.add(button2);
			
			button3 = new JButton("Problemas");
			button3.setBounds(402, 123, 154, 41);		
			panel.add(button3);
			
			button4 = new JButton("Configura\u00E7\u00F5es");
			button4.setBounds(521, 412, 154, 41);
			panel.add(button4);
			
			button5 = new JButton("FAQ");
			button5.setBounds(126, 196, 154, 41);
			panel.add(button5);
			
			button6 = new JButton("Contatos");
			button6.setBounds(126, 273, 154, 41);
			panel.add(button6);
			
			button7 = new JButton("Deletar Problemas");
			button7.setBounds(402, 273, 154, 41);
			panel.add(button7);

		}
}
