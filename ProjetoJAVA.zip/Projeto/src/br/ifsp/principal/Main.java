package br.ifsp.principal;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.hibernate.Session;

import br.ifsp.controller.LoginController;
import br.ifsp.dao.ProblemaDAO;
import br.ifsp.dao.UsuarioDAO;
import br.ifsp.hibernateAcesso.HibernateAcesso;
import br.ifsp.model.Problema;
import br.ifsp.model.Usuario;
import br.ifsp.view.TelaLogin;

public class Main {
	static Frame frame1;
	public static void main(String[] args) {
		frame1 = new Frame("Bragan\u00E7a Paulista Help");
		frame1.setBackground(Color.BLACK);
		frame1.setLayout(new GridLayout(0, 1));
		frame1.setSize(700, 500);
		
		Panel panelEntrar = new Panel();
		panelEntrar.setLayout(null);
			
		Usuario usuario = new Usuario();
	
		frame1.add(panelEntrar);
		
		JLabel lblBraganaPaulistaHelp = new JLabel("Bragan\u00E7a Paulista Help");
		lblBraganaPaulistaHelp.setForeground(Color.WHITE);
		lblBraganaPaulistaHelp.setFont(new Font("Times New Roman", Font.BOLD, 51));
		lblBraganaPaulistaHelp.setBackground(Color.WHITE);
		lblBraganaPaulistaHelp.setBounds(71, 73, 561, 60);
		
		
		panelEntrar.add(lblBraganaPaulistaHelp);
		
		JButton btnIniciar = new JButton("Iniciar");
		btnIniciar.setBounds(264, 211, 129, 60);
		
		btnIniciar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				TelaLogin telaLogin = new TelaLogin();
				LoginController l = new LoginController(telaLogin,null);
				l.inicializaController();
			}
		});
		
		panelEntrar.add(btnIniciar);
		frame1.setVisible(true);
	}
	
}


